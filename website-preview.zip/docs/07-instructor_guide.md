
# (PART\*) Instructor Guide {-}

# Notes about the Activity

Coming soon!

# Additional Lecture Material

Coming soon!

# Using AnVIL

This activity was designed to work on local installations of RStudio, Posit cloud, or using NHGRI's cloud computing platform [AnVIL](https://anvil.terra.bio/). If you'd like to get started with using AnVIL in the classroom, checkout the [AnVIL Instructor's Guide](https://jhudatascience.org/AnVIL_Book_Instructor_Guide/index.html). This guide includes information on setting up billing, using premade content (or developing your own), and managing costs. There are also details guides on exploring and using AnVIL for students. 

